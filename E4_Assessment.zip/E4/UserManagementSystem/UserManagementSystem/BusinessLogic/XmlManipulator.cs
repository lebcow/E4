﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;
using UserManagementSystem.ConfigSettings;

namespace UserManagementSystem.BusinessLogic
{
    public class XmlManipulator : IXmlManipulator
    {
        public Config _Config;
        string filepath;

        public XmlManipulator(Config Config)
        {
            _Config = Config;
            filepath = _Config.Folder + _Config.Filename;
        }

        public T DeserializeToObject<T>() where T : class
        {
            if (File.Exists(filepath) == true)
            {
                System.Xml.Serialization.XmlSerializer ser = new System.Xml.Serialization.XmlSerializer(typeof(T));

                using (StreamReader sr = new StreamReader(filepath))
                {
                    return (T)ser.Deserialize(sr);
                }
            }
            else
                return null;
        }

        public bool SerializeToXml<T>(T anyobject)
        {
            try
            {
                if (Directory.Exists(_Config.Folder) == false)
                    Directory.CreateDirectory(_Config.Folder);

                XmlSerializer xmlSerializer = new XmlSerializer(anyobject.GetType());

                using (StreamWriter writer = new StreamWriter(filepath))
                {
                    xmlSerializer.Serialize(writer, anyobject);
                }
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }
    }
}
