﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserManagementSystem.Models;

namespace UserManagementSystem.BusinessLogic
{
    public interface IUsers
    {
        bool AddUser(User user);

        bool UpdateUser(User user);

        bool DeleteUser(string CellNumber);

        List<User> GetAllUsers();

        User GetlUser(string CellNumber);
    }
}
