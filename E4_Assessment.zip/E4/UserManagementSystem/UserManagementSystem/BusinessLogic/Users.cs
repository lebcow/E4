﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserManagementSystem.Models;

namespace UserManagementSystem.BusinessLogic
{
    public class Users : IUsers
    {
        public IXmlManipulator _IXmlManipulator;

        private List<User> users;

        public Users(IXmlManipulator IXmlManipulatortext)
        {
            _IXmlManipulator = IXmlManipulatortext;
            users = _IXmlManipulator.DeserializeToObject<List<User>>() != null ? _IXmlManipulator.DeserializeToObject<List<User>>() : new List<User>();
        }

        public bool AddUser(User user)
        {
            users.Add(user);
            return _IXmlManipulator.SerializeToXml(users);
        }

        public bool UpdateUser(User user)
        {
            //get user index in the list and update it
            int userIndex = users.FindIndex(a => a.cellNumber == user.cellNumber);
            users[userIndex] = user;

            return _IXmlManipulator.SerializeToXml(users);
        }

        public bool DeleteUser(string CellNumber)
        {
            //get user index in the list and update it
            int userIndex = users.FindIndex(a => a.cellNumber == CellNumber);
            users.RemoveAt(userIndex);

            return _IXmlManipulator.SerializeToXml(users);
        }

        public List<User> GetAllUsers()
        {
            return users;
        }

        public User GetlUser(string CellNumber)
        {
            return users.Where(a => a.cellNumber == CellNumber).FirstOrDefault();
        }
    }
}
