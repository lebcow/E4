﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserManagementSystem.ConfigSettings;

namespace UserManagementSystem.BusinessLogic
{
   public interface IXmlManipulator
    {
        T DeserializeToObject<T>() where T : class;

        bool SerializeToXml<T>(T anyobject);
    }
}
