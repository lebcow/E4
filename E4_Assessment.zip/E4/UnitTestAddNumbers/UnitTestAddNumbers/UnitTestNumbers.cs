﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using AddNumbersNew;
using System.Windows.Forms;

namespace UnitTestAddNumbers
{
    [TestClass]
    public class UnitTestNumbers
    {
        [TestMethod]
        public void Test_AddNumbers()
        {
            frmAddNumbers addNumbers = new frmAddNumbers();

            int results = addNumbers.AddNumbers("1,2,3,4,5");

            Assert.IsTrue(results > 0);
        }

        [TestMethod]
        public void Test_NewLineDelimeter()
        {
            frmAddNumbers addNumbers = new frmAddNumbers();

            int results = addNumbers.AddNumbers("1\n2\n3\n4\n5");

            Assert.IsTrue(results > 0);
        }

        [TestMethod]
        public void Test_EmptyParameter()
        {
            frmAddNumbers addNumbers = new frmAddNumbers();

            int results = addNumbers.AddNumbers(string.Empty);

            Assert.IsTrue(results == 0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "-1,-2,-3")]
        public void Test_NegativeNumbers()
        {
            frmAddNumbers addNumbers = new frmAddNumbers();
            addNumbers.AddNumbers("-1,-2,-3");
        }

        [TestMethod]
        public void Test_CustomDelimeter()
        {
            frmAddNumbers addNumbers = new frmAddNumbers();

            int results = addNumbers.AddNumbers("//;1,2;3;4,5");

            Assert.IsTrue(results > 0);
        }
    }
}
