﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddNumbersNew
{
    public partial class frmAddNumbers : Form
    {
        public frmAddNumbers()
        {
            InitializeComponent();
        }

        private bool IsNumeric(string value)
        {
            return int.TryParse(value, out int n);
        }

        private string[] ExtractNumbers(string numbers)
        {
            char newDelimeter = default(char);

            if (numbers.Substring(0, 2).Trim() == "//") //check the first 2 characters
            {
                newDelimeter = char.Parse(numbers.Substring(2, 1)); //get delimeter after //
            }

            return numbers.Split(new char[] { ',', '\n', newDelimeter }, StringSplitOptions.RemoveEmptyEntries).Where(x => IsNumeric(x) == true).ToList().ToArray();
        }

        public int AddNumbers(string numbers)
        {
            int total = 0;

            try
            {
                if (string.IsNullOrEmpty(numbers) == false)
                {
                    string[] splittedNumbers = ExtractNumbers(numbers);
                    var negativeNumbers = String.Join(",", splittedNumbers.Where(x => x.Contains("-") == true).ToList().ToArray());

                    if (string.IsNullOrEmpty(negativeNumbers) == false)
                    {
                        throw new ArgumentException(" Negatives not allowed : " + negativeNumbers);
                    }

                    int sum = splittedNumbers.Where(x => x.Contains("-") == false).Select(s => int.Parse(s)).ToList().Sum();

                    total = sum;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return total;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                txtNumbers.Text = "-1,-3,-3";
                int total = AddNumbers(txtNumbers.Text);
                MessageBox.Show("Total is : " + total.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
