﻿using StudentWebAPI.BusinessLogic.Interfaces;
using StudentWebAPI.Models;
using StudentWebAPI.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentWebAPI.BusinessLogic
{
    public class Students : IStudents
    {
        private readonly E4DbContext _dbContext;

        public Students(E4DbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public List<Student> GetStudents()
        {
            return _dbContext.Students.Take(3).ToList();
        }

        public bool CreateStudent(Student student)
        {
            try
            {
                student.DateCreated = DateTime.Now;
                _dbContext.Add(student);
                return Convert.ToBoolean(_dbContext.SaveChanges());
            }
            catch (Exception ex)
            {
                //write to log file
            }

            return false;
        }

        public bool UpdateStudent(Student student)
        {
            try
            {
                var existingStudent = _dbContext.Students.FirstOrDefault(a => a.IdNumber == student.IdNumber);

                if (existingStudent != null)
                {
                    existingStudent.Name = student.Name;
                    existingStudent.IdNumber = student.IdNumber;
                    existingStudent.Age = student.Age;
                    existingStudent.DateModified =DateTime.Now; 

                    return Convert.ToBoolean(_dbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                //write to log file
            }

            return false;
        }

        public bool DeleteStudent(string IdNumber)
        {
            try
            {
                var existingStudent = _dbContext.Students.FirstOrDefault(a => a.IdNumber == IdNumber);

                if (existingStudent != null)
                {
                    _dbContext.Remove(existingStudent);
                    return Convert.ToBoolean(_dbContext.SaveChanges());
                }
            }
            catch (Exception ex)
            {
                //write to log file
            }

            return false;
        }
    }
}
