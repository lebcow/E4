﻿using StudentWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentWebAPI.BusinessLogic.Interfaces
{
    public interface IStudents
    {
        List<Student> GetStudents();

        bool CreateStudent(Student student);

        bool UpdateStudent(Student student);

        bool DeleteStudent(string IdNumber);
    }
}
