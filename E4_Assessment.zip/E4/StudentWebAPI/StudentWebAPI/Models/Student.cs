﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace StudentWebAPI.Models
{
    [Table("students")]
    public partial class Student
    {
        [Key]
        [Column("id")]
        [JsonIgnore]
        public int Id { get; set; }

        [Required]
        [Column("name")]
        [StringLength(50)]
        public string Name { get; set; }

        [Required]
        [Column("id_number")]
        [StringLength(13)]
        public string IdNumber { get; set; }

        [Column("age")]
        public int? Age { get; set; }

        [Column("date_created", TypeName = "datetime")]
        [JsonIgnore]
        public DateTime? DateCreated { get; set; }

        [Column("date_modified", TypeName = "datetime")]
        [JsonIgnore]
        public DateTime? DateModified { get; set; }
    }
}
