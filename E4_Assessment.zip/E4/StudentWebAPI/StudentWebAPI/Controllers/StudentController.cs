﻿using Microsoft.AspNetCore.Mvc;
using StudentWebAPI.BusinessLogic.Interfaces;
using StudentWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentWebAPI.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudents _student;

        public StudentController(IStudents student)
        {
            _student = student;
        }

        [HttpGet("GetStudents")]

        public ActionResult<List<Student>> GetAllCustomers()
        {
            return Ok(_student.GetStudents());
        }

        [HttpPost("CreateStudent")]

        public ActionResult<bool> CreateStudent([FromBody] Student student)
        {
            if (_student.CreateStudent(student) == true)
                return Ok("Student was created successfully");
            else
                return BadRequest("Failed to create a Student");
        }

        [HttpPut("UpdateStudent")]

        public ActionResult<bool> UpdateStudent([FromBody] Student student)
        {
            if (_student.UpdateStudent(student) == true)
                return Ok("Student was updated successfully");
            else
                return BadRequest("Failed to update a Student");
        }

        [HttpDelete("DeleteStudent")]

        public ActionResult<bool> DeleteStudent(string IdNumber)
        {
            if (_student.DeleteStudent(IdNumber) == true)
                return Ok("Student was deleted successfully");
            else
                return BadRequest("Failed to update a Student");
        }
    }
}
